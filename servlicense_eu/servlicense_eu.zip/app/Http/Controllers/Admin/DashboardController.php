<?php


namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;

class DashboardController extends Controller
{

    public function showDashboard()
    {
        return view('admin.dashboard');
    }

    public function ajaxSessionsLoad()
    {
//        return datatables($this->user()->sessions())->setTransformer(new SessionTransformer())->toJson();
    }

}
