<?php


namespace App\Http\Controllers\Admin\Licensor\Single;


use App\Http\Controllers\Controller;
use App\Models\User;

class LicensorSingleController extends Controller
{

    public function showLicensor(User $licensor)
    {
        $google2fa = app('pragmarx.google2fa');
        return $google2fa->generateSecretKey();
        return view('admin.licensor.single.index', compact('licensor'));
    }

    public function updateLicensor()
    {
        static::validateAjax();
        return response()->json([
            'success' => false,
        ]);
    }

}
