<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail as MustVerifyEmailAlias;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable implements MustVerifyEmailAlias
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'role', 'payload'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'payload' => 'array'
    ];

    /**
     * Checking if the requested role has
     *
     * @param string $role
     * @return bool
     */
    public function hasRole(string $role): bool
    {
        return $this->role == $role;
    }

    /**
     * Determine if this model doesn't own the given model.
     *
     * @param  \Illuminate\Database\Eloquent\Model $model
     * @param  mixed                               $foreignKey
     * @param  bool                                $strict
     *
     * @return bool
     */
    public function doesntOwn($model, $foreignKey = null, $strict = false )
    {
        return !$this->owns($model, $foreignKey, $strict);
    }

    /**
     * Determine if this model owns the given model.
     *
     * @param  \Illuminate\Database\Eloquent\Model $model
     * @param  mixed                               $foreignKey
     * @param  bool                                $strict
     *
     * @return bool
     */
    public function owns($model, $foreignKey = null, $strict = false )
    {
        $foreignKey = $foreignKey ?: $this->getForeignKey();
        if ( $strict ) {
            return $this->getKey() === $model->{$foreignKey};
        }

        return $this->getKey() == $model->{$foreignKey};
    }

    /**
     * Make the first letter of the roll big
     *
     * @return string
     */
    public function convertedRole()
    {
        return strtoupper(substr($this->role, 0, 1)).strtolower(substr($this->role, 1));
    }

    public function sessions()
    {
        return $this->hasMany(Session::class, 'user_id', 'id');
    }

}
