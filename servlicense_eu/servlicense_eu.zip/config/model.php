<?php

return [

    'default_path' => 'Models'

];
